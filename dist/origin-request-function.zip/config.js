var config = module.exports = {image_bucket:"imagemanager-imagebucket-132exspf1grey",apigw_url:"https://v8j30qidh4.execute-api.ap-south-1.amazonaws.com/prod"}
